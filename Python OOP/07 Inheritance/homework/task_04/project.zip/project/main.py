from project.sports_car import SportsCar

sports_car = SportsCar()
print(sports_car.race())
print(sports_car.drive())
print(sports_car.move())