from project.fruit import Fruit

f = Fruit("Banana", 1)
print(f.expiration_date)
print(f.name)
