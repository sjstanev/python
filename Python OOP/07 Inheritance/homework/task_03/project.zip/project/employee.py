class Employee:

    def get_fired(self) -> str:
        return "fired..."